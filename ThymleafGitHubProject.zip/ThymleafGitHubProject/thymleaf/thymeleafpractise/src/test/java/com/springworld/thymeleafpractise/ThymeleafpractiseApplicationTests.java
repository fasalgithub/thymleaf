package com.springworld.thymeleafpractise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafpractiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
