package com.springworld.thymeleafpractise.model;

public class MyThymeLeaf 
{
	private String thymeLeafName;
	private String thymeLeafAge;
	
	
	public MyThymeLeaf()
	{
		
	}
	
	public MyThymeLeaf(String thymeLeafName, String thymeLeafAge) {
		super();
		this.thymeLeafName = thymeLeafName;
		this.thymeLeafAge = thymeLeafAge;
	}
	
	
	public String getThymeLeafName() {
		return thymeLeafName;
	}
	public void setThymeLeafName(String thymeLeafName) {
		this.thymeLeafName = thymeLeafName;
	}
	public String getThymeLeafAge() {
		return thymeLeafAge;
	}
	public void setThymeLeafAge(String thymeLeafAge) {
		this.thymeLeafAge = thymeLeafAge;
	}
	@Override
	public String toString() {
		return "MyThymeLeaf [thymeLeafName=" + thymeLeafName + ", thymeLeafAge=" + thymeLeafAge + "]";
	}
	
	
	
	

}
