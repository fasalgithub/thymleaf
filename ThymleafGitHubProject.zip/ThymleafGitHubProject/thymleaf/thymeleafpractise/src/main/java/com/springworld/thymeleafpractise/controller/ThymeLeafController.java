package com.springworld.thymeleafpractise.controller;


import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.springworld.thymeleafpractise.model.MyThymeLeaf;


@Controller
public class ThymeLeafController 
{
   	
	
	@RequestMapping(path ="/thymeleaf",method = RequestMethod.GET)
	public ModelAndView getMyInfo() 
	{
		ModelAndView model = new ModelAndView();
		
	    MyThymeLeaf leaf = new MyThymeLeaf();
	    leaf.setThymeLeafName("fasal");
	    leaf.setThymeLeafAge("500");
	    
	    model.setViewName("thymeleafTemplate");
	    model.addObject("myleaf", leaf);
		
		return model;
	}
	
	@RequestMapping(value = "/my-all-leafs",method = RequestMethod.GET)
	private ModelAndView getAllThyms() 
	{
		ModelAndView modelAndView = new ModelAndView();
		
		List<MyThymeLeaf> listofmyleaf = Arrays.asList(new MyThymeLeaf("sharvesh", "230"), new MyThymeLeaf("kiruba", "700"));
		modelAndView.setViewName("thymeleafTemplate");
		modelAndView.addObject("leafs", listofmyleaf);
		
		return modelAndView;
	}
	
	@RequestMapping(path="/leaners",method = RequestMethod.GET)
	public ModelAndView getAllMyLeaners()
	{
	   ModelAndView modelAndView = new ModelAndView();	
	   List<String> names = Arrays.asList("sharvesh","fasal","kirubs");
	   modelAndView.setViewName("thymeleaf-names");
	   modelAndView.addObject("myList", names);
	   return modelAndView;
	   
	}
	
	
	

}
