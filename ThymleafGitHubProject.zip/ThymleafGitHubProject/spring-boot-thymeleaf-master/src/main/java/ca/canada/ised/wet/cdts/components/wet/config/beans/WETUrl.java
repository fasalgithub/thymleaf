/**
 *
 */
package ca.canada.ised.wet.cdts.components.wet.config.beans;

/**
 * @author pitta
 *
 */
public class WETUrl {

    private String url;

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }

}
